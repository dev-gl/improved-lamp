using System;
using Database.Core;

namespace Database
{
    static class Program
    {
        static void Main()
        {
            var dataWriter = new DataWriter("Storage");

            dataWriter.Write("File1");
        }
    }
}
