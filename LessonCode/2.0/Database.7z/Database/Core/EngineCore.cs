﻿using System.Threading.Tasks;

namespace Database
{
    public class EngineCore : IEngineCore
    {

        public void Destroy()
        {

        }

        public void Load()
        {
        }

        public string Query(string queryText)
        {

            return "No Results Found";
        }

    }
}
