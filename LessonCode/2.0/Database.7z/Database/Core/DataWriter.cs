﻿using System.IO;

namespace Database.Core
{
    class DataWriter
    {
        private string _directory;
        private uint _counter;

        public DataWriter(string directoryName)
        {
            _directory = directoryName;
            _counter = 0;
            Directory.CreateDirectory(directoryName);
        }

        public void Write(string text)
        {
            var filePath = "./";
            filePath += _directory;
            filePath += "/";
            filePath += _counter.ToString();
            filePath += ".txt";

            File.WriteAllText(filePath, text);

            _counter += 1;
        }
    }
}
